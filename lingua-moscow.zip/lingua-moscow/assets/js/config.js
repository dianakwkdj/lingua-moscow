// LinguaMoscow — config

window.LM_CONFIG = {
  API_BASE_URLS: [
    "https://exam-api-courses.std-900.ist.mospolytech.ru",
    "http://exam-api-courses.std-900.ist.mospolytech.ru",
  ],

  API_KEY: "305fc4a6-3ade-4ad3-a4cb-aca24fb5ede5",

  PAGE_SIZE: 5,
  
  YANDEX_MAPS_API_KEY: "32ee8f25-d5c6-48fc-b33c-010d22a9fd8d",

  CITY: "Москва",
};
